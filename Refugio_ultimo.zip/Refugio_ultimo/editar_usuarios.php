<?php

session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Administrador') {
    header("Location: login.php");
    exit();
}

// Conexion a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "refugio";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexion fallida: " . $conn->connect_error);
}

// Actualizar datos del usuario si se envió el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['actualizar'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $usuario = $_POST['usuario'];
    $correo = $_POST['correo'];
    $numero = $_POST['numero'];
    $contraseña = $_POST['contraseña'];
    $rol = $_POST['rol'];

    $sql = "UPDATE registro SET nombre=?, usuario=?, correo=?, numero=?, contraseña=?, rol=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssi", $nombre, $usuario, $correo, $numero, $contraseña, $rol, $id);
    $stmt->execute();
}

// Obtener todos los usuarios
$sql = "SELECT * FROM registro";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Editar Usuarios</h2>
    <a href="admin_panel.php" class="btn btn-secondary mb-3">Volver al Panel</a>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Usuario</th>
                <th>Correo</th>
                <th>Numero</th>
                <th>Contraseña</th>
                <th>Rol</th>
                <th>Accion</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <form method="POST">
                    <td><?php echo $row['id']; ?></td>
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <td><input type="text" name="nombre" value="<?php echo $row['nombre']; ?>" class="form-control"></td>
                    <td><input type="text" name="usuario" value="<?php echo $row['usuario']; ?>" class="form-control"></td>
                    <td><input type="email" name="correo" value="<?php echo $row['correo']; ?>" class="form-control"></td>
                    <td><input type="text" name="numero" value="<?php echo $row['numero']; ?>" class="form-control"></td>
                    <td><input type="text" name="contraseña" value="<?php echo $row['contraseña']; ?>" class="form-control"></td>
                    <td>
                        <select name="rol" class="form-select">
                            <option value="Usuario" <?php if ($row['rol'] == 'Usuario') echo 'selected'; ?>>Usuario</option>
                            <option value="Empleado" <?php if ($row['rol'] == 'Empleado') echo 'selected'; ?>>Empleado</option>
                            <option value="Administrador" <?php if ($row['rol'] == 'Administrador') echo 'selected'; ?>>Administrador</option>
                        </select>
                    </td>
                    <td><button type="submit" name="actualizar" class="btn btn-success">Guardar</button></td>
                </form>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
</body>
</html>
<?php $conn->close(); ?>
