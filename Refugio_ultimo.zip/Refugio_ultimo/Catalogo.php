<?php
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Usuario') {
    header("Location: login.php");
    exit();
}

$conexion = new mysqli("localhost", "root", "", "refugio");
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

$sql = "SELECT * FROM gatitos";
$resultado = $conexion->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Catálogo de Gatitos para Adoptar</title>
    <link rel="stylesheet" href="CSS/catalogoestilo.css">
</head>
<body>
<div class="contenedor">
    <h1>Gatitos para Adoptar</h1>

    <?php while ($row = $resultado->fetch_assoc()): ?>
        <div class="gatito">
            <!--linea cambiada-->
            <img class="foto" src="<?php echo htmlspecialchars($row['imagen']); ?>" alt="Gatito">

            <div class="informacion">
                <p class="nombre"><?php echo htmlspecialchars($row['nombre']); ?></p>
                <p class="edad"><?php echo htmlspecialchars($row['edad']); ?></p>
                <p class="raza"><?php echo htmlspecialchars($row['raza']); ?></p>
            </div>
            <!-- Enviar id por GET -->
            <a href="cuestionario.php?id=<?php echo $row['id']; ?>" class="adoptar">Adoptar</a>
        </div>
    <?php endwhile; ?>

    <button onclick="window.location.href='index.php'" class="boton-regresar">Regresar a la página principal</button>
</div>
</body>
</html>
