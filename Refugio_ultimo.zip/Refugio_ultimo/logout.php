<?php
/*session_start();
session_unset();
session_destroy();

// Redirigir al login
header("Location: login.php");
exit();
?>

session_start();
session_unset();
session_destroy();

// Prevenir que el usuario use el botón "Atrás"
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

header("Location: login.php");
exit;
*/
session_start();

// Eliminar todas las variables de sesión
$_SESSION = [];
session_unset();
session_destroy();

// Borrar cookie si existe
if (isset($_COOKIE['usuario'])) {
    setcookie("usuario", "", time() - 3600, "/");
}

// Evitar que se pueda usar el botón de retroceso
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

// Redirigir al login
header("Location: login.php");
exit;
?>
