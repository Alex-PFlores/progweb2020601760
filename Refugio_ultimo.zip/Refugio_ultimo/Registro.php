<?php
// Mostrar errores (quitar en producción)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "refugio";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Variables para SweetAlert
$mensajeJS = '';
$mostrarAlerta = false;

// Procesar formulario
if (isset($_POST['registro'])) {
    $nombre = trim($_POST['nombre']);
    $usuario = trim($_POST['usuario']);
    $correo = trim($_POST['correo']);
    $numero = trim($_POST['numero']);
    $contraseña = password_hash($_POST['contraseña'], PASSWORD_DEFAULT); // Encriptar contraseña
    $rol = "Usuario";

    $sql = "INSERT INTO registro (nombre, usuario, correo, numero, contraseña, rol)
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $nombre, $usuario, $correo, $numero, $contraseña, $rol);

    if ($stmt->execute()) {
        // Registro exitoso
        $mensajeJS = "
            Swal.fire({
                icon: 'success',
                title: 'Usuario Registrado Exitosamente',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            }).then(() => {
                window.location.href = 'login.php';
            });
        ";
        $mostrarAlerta = true;
    } else {
        // Error al registrar
        $error = addslashes($stmt->error);
        $mensajeJS = "
            Swal.fire({
                icon: 'error',
                title: 'Error al registrar',
                text: '$error',
                confirmButtonText: 'Intentar de nuevo'
            });
        ";
        $mostrarAlerta = true;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="CSS/registro.css" />
</head>
<body>
    <div class="header">
        <h1>Centro de Adopción de Gatitos</h1>
    </div>

    <div class="contenedor">
        <h2>Registro de Usuario</h2>
        <form method="POST" autocomplete="off">
            <div class="campo">
                <input type="text" name="nombre" placeholder="Nombre" required />
            </div>
            <div class="campo">
                <input type="text" name="usuario" placeholder="Usuario" required />
            </div>
            <div class="campo">
                <input type="email" name="correo" placeholder="Correo electrónico" required />
            </div>
            <div class="campo">
                <input type="text" name="numero" placeholder="Número de teléfono" required />
            </div>
            <div class="campo">
                <input type="password" name="contraseña" placeholder="Contraseña" required />
            </div>
            <div class="campo">
                <button type="submit" name="registro">Registrarse</button>
            </div>
        </form>
    </div>

    <div class="footer">
        <p>© 2025 Centro de Adopción de Gatitos. Todos los derechos reservados. UPIICSA.</p>
    </div>

    <!-- Cargar SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php
    if ($mostrarAlerta) {
        echo "<script>$mensajeJS</script>";
        exit();
    }
    ?>
</body>
</html>
