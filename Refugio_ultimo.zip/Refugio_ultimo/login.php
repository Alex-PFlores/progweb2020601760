<?php
// Mostrar errores para depuración (quitar en producción)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
// Si ya hay sesión activa, redirigir según rol
if (isset($_SESSION['usuario']) && isset($_SESSION['rol'])) {
    $redireccion = match ($_SESSION['rol']) {
        "Administrador" => "admin_panel.php",
        "Empleado" => "panel_trabajador.php",
        default => "index.php",
    };
    header("Location: $redireccion");
    exit;
}


// Variables para control de mensajes
$mensajeJS = ''; // Código JS para SweetAlert
$mostrarAlerta = false;

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "refugio";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Procesar formulario solo si se envió
if (isset($_POST['login'])) {
    $usuario = trim($_POST['usuario']);
    $contraseña = trim($_POST['contraseña']);

    $stmt = $conn->prepare("SELECT * FROM registro WHERE usuario = ?");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();

        if (password_verify($contraseña, $row['contraseña'])) {
            // Login exitoso
            $_SESSION['usuario'] = $usuario;
            $_SESSION['rol'] = $row['rol'];

            if (isset($_POST['recordarme'])) {
                setcookie("usuario", $usuario, time() + (86400 * 30), "/");
            } else {
                setcookie("usuario", "", time() - 3600, "/");
            }

            $mensaje = "¡Adelante! Tienes acceso al sistema,  " . $row['nombre'];
            $redireccion = match ($row['rol']) {
                "Administrador" => "admin_panel.php",
                "Empleado" => "panel_trabajador.php",
                default => "index.php",
            };

            $mensajeJS = "
                Swal.fire({
                    icon: 'success',
                    title: '¡Bienvenido!',
                    text: '$mensaje',
                    confirmButtonText: '¡Gracias!'
                }).then(() => {
                    window.location.href = '$redireccion';
                });
            ";
            $mostrarAlerta = true;
        } else {
            // Contraseña incorrecta
            $mensajeJS = "
                Swal.fire({
                    icon: 'error',
                    title: 'Acceso denegado',
                    text: 'Contraseña incorrecta',
                    timer: 3000,
                    showConfirmButton: false,
                    timerProgressBar: true
                }).then(() => {
                    window.location.href = 'login.php';
                });
            ";
            $mostrarAlerta = true;
        }
    } else {
        // Usuario no encontrado
        $mensajeJS = "
            Swal.fire({
                icon: 'error',
                title: 'Acceso denegado',
                text: 'Usuario no encontrado',
                timer: 3000,
                showConfirmButton: false,
                timerProgressBar: true
            }).then(() => {
                window.location.href = 'login.php';
            });
        ";
        $mostrarAlerta = true;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Inicio de Sesión</title>
    <link rel="stylesheet" href="CSS/login.css" />
</head>
<body>
	<div class="wrapper">
    <div class="header">
        <h1>Centro de Adopción de Gatitos</h1>
    </div>
    <div class="contenedor">
        <h2>Iniciar Sesión</h2>
        <form method="POST" action="" autocomplete="off">
            <div class="campo">
                <input type="text" id="usuario" name="usuario" placeholder="Usuario" autocomplete="username" required
                    value="<?php echo isset($_COOKIE['usuario']) ? htmlspecialchars($_COOKIE['usuario']) : ''; ?>" />
            </div>
            <div class="campo">
                <input type="password" id="contraseña" name="contraseña" placeholder="Contraseña" autocomplete="current-password" required />
            </div>
            <div class="campo recordarme-container">
                <label class="recordarme-label">
                    <input type="checkbox" class="recordarme-checkbox" name="recordarme" id="recordarme"
                        <?php if (isset($_COOKIE['usuario'])) echo "checked"; ?> />
                    Recordarme
                </label>
            </div>
            <div class="campo">
                <button type="submit" name="login">Iniciar Sesión</button>
            </div>
        </form>
        <div class="campo">
            <button onclick="window.location.href='Registro.php'" class="register-button">Registrarse</button>
        </div>
    </div>
    <div class="footer">
        <p>© 2025 Centro de Adopción de Gatitos. Todos los derechos reservados. UPIICSA</p>
    </div>

    <!-- Cargamos SweetAlert2 justo antes de cerrar el body -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	</div>

    <?php
    // Si hay alerta que mostrar, la imprimimos aquí
    if ($mostrarAlerta) {
        echo "<script>$mensajeJS</script>";
        // Salir para evitar que se muestre el formulario después del mensaje de éxito
        if (isset($_POST['login']) && isset($_SESSION['usuario'])) {
            exit();
        }
    }
    ?>
</body>
</html>
