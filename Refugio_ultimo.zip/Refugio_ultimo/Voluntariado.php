<?php
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Usuario') {
    header("Location: login.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Voluntariado Refugio de Gatitos</title>
    <link rel="stylesheet" href="CSS/Voluntariado.css">
</head>
<body>
    <div class="contenedor">
        <h1 class="titulo">Voluntariado Refugio de Gatitos</h1>
        <img class="imagen" src="https://gatogazzu.org/wp-content/uploads/2022/06/voluntario-1024x375.jpg" alt="Gatitos">
        <p class="descripcion">
            ¡Únete a nuestro equipo de voluntarios y ayuda a cuidar a nuestros adorables gatitos! 
            Nuestro refugio necesita personas comprometidas y apasionadas por los animales para ayudar en 
            tareas como:
        </p>
        <ul>
            <li>Cuidado y alimentación de los gatitos</li>
            <li>Limpieza y mantenimiento del refugio</li>
            <li>Asistencia en eventos y actividades</li>
            <li>Ayuda en la adopción de gatitos</li>
        </ul>
        <div class="botones">
            <button class="boton" onclick="window.location.href='Infocat.php'">Más información</button>
            <button onclick="window.location.href='index.php'" class="boton-regresar">Regresar a la página principal</button>
        </div>
    </div>
</body>
</html>
