<?php
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Usuario') {
    header("Location: login.php");
    exit();
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'conexion.php';

    if (isset($_POST['nombre']) && isset($_POST['email']) && isset($_POST['mensaje'])) {
        $nombre = trim($_POST['nombre']);
        $email = trim($_POST['email']);
        $mensaje = trim($_POST['mensaje']);

        if (empty($nombre) || empty($email) || empty($mensaje)) {
            echo "<script>
                    alert('Por favor, completa todos los campos.');
                    window.history.back();
                  </script>";
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO contactos (nombre, email, mensaje) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $nombre, $email, $mensaje);

        if ($stmt->execute()) {
            echo "<script>
                    alert('Mensaje enviado correctamente');
                    window.location.href = 'index.php';
                  </script>";
        } else {
            echo "<script>
                    alert('Error al guardar el mensaje: " . addslashes($stmt->error) . "');
                    window.history.back();
                  </script>";
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "<script>
                alert('Faltan campos en el formulario.');
                window.history.back();
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Contacto Refugio de Gatitos</title>
    <link rel="stylesheet" href="CSS/Contacto.css">
</head>
<body>
    <div class="contenedor">
        <h1 class="titulo">Contacto Refugio de Gatitos</h1>
        <p>¡Contáctanos para ayudar a nuestros adorables gatitos!</p>
        <form action="Contacto.php" method="POST" autocomplete="off">
            <label class="etiqueta" for="nombre">Nombre:</label>
            <input class="campo" type="text" id="nombre" name="nombre" placeholder="Tu nombre completo" required>
            
            <label class="etiqueta" for="email">Correo electrónico:</label>
            <input class="campo" type="email" id="email" name="email" placeholder="Tu correo electrónico" required>
            
            <label class="etiqueta" for="mensaje">Mensaje:</label>
            <textarea class="campo" id="mensaje" name="mensaje" placeholder="Escribe tu mensaje aquí..." rows="5" required></textarea>
            
            <button type="submit" class="boton">Enviar</button>
        </form>
        
        <p>También puedes contactarnos a través de:</p>
        <ul>
            <li>Teléfono: 555-555-5555</li>
            <li>Dirección: Calle 123, Col. ABC, Ciudad</li>
            <li>Redes sociales: @refugiodegatitos</li>
        </ul>
        <button onclick="window.location.href='index.php'" class="boton-regresar">Regresar a la página principal</button>
    </div>
</body>
</html>
